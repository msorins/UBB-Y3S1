package PIF

type PifStruct struct {
	codification int
	positionInST int
}
