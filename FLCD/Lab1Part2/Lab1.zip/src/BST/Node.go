package BST

type Node struct {
	Id int
	Val string
	Left *Node
	Right *Node
}
