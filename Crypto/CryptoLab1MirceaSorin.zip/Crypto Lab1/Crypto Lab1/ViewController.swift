//
//  ViewController.swift
//  Crypto Lab1
//
//  Created by Sorin Sebastian Mircea on 22/10/2018.
//  Copyright © 2018 Sorin Sebastian Mircea. All rights reserved.
//

import UIKit

extension String {
    
    func index(at position: Int, from start: Index? = nil) -> Index? {
        let startingIndex = start ?? startIndex
        return index(startingIndex, offsetBy: position, limitedBy: endIndex)
    }
    
    func character(at position: Int) -> Character? {
        guard position >= 0, let indexPosition = index(at: position) else {
            return nil
        }
        return self[indexPosition]
    }
}

extension StringProtocol {
    var ascii: [UInt32] {
        return unicodeScalars.compactMap { $0.isASCII ? $0.value : nil }
    }
}
extension Character {
    var ascii: UInt32? {
        return String(self).ascii.first
    }
}

class ViewController: UIViewController, UITextViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var plainTextField: UITextField!
    @IBOutlet weak var keyTextField: UITextField!
    @IBOutlet weak var cypherTextField: UITextField!
    
    @IBOutlet weak var encryptButton: UIButton!
    @IBOutlet weak var decryptButton: UIButton!
    
    var isPlainTextFieldOK  : Bool = false;
    var isKeyTextFieldOK    : Bool = false;
    var isCypherTextFieldOK : Bool = false;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add field text changed events
        plainTextField.addTarget(self, action: #selector(fieldTextChanged), for: .editingChanged)
        keyTextField.addTarget(self, action: #selector(fieldTextChanged), for: .editingChanged)
        cypherTextField.addTarget(self, action: #selector(fieldTextChanged), for: .editingChanged)
    }
    
    @objc func fieldTextChanged(_ sender: UITextField) {
        
        // Plain text must have small letters alphabet + space
        if(sender == plainTextField) {
          let alphabet = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyz ")
            if alphabet.isStrictSuperset(of: CharacterSet(charactersIn: plainTextField.text!)) && plainTextField.text!.count != 0 {
                isPlainTextFieldOK = true
            } else {
                isPlainTextFieldOK = false
            }
        }
        
        // Key text must be an int
        if(sender == keyTextField) {
            let plainInt = (Int(sender.text!))
            if let goodInt = plainInt  {
                if(goodInt != 0) {
                    isKeyTextFieldOK = true;
                } else {
                    isKeyTextFieldOK = false;
                }
            } else {
                isKeyTextFieldOK = false;
            }
        }
        
        // Cypher text must have big letters alphabet + space
        if(sender == cypherTextField) {
            let alphabet = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZ ")
            if alphabet.isStrictSuperset(of: CharacterSet(charactersIn: cypherTextField.text!)) && cypherTextField.text!.count != 0 {
                isCypherTextFieldOK = true
            } else {
                isCypherTextFieldOK = false
            }
        }
        
        // Enable && disable the buttons according to the inputs
        if(isPlainTextFieldOK && isKeyTextFieldOK) {
            encryptButton.isEnabled = true
        } else {
            encryptButton.isEnabled = false
        }
        
        if(isCypherTextFieldOK && isKeyTextFieldOK) {
            decryptButton.isEnabled = true
        } else {
            decryptButton.isEnabled = false
        }
    }
    
    @IBAction func encryptTouchDown(_ sender: Any) {
        let txt = plainTextField.text!
        var encrypted: String = ""
        
        // Do the encryption
        let plainInt = (Int(keyTextField.text!))
        if let goodInt = plainInt as? Int {
            print("intrat")
            print(txt)
            for chr in txt {
                var newChr: Character
            
                var ascii = Int(UnicodeScalar(String(chr))!.value)
                if ascii == 32 {
                    ascii = 26
                } else {
                    ascii -= 97;
                }
                    
                ascii = (ascii + goodInt) % 27
                if(ascii < 0) {
                    ascii = 27 + ascii;
                }
                if(ascii == 26) {
                    newChr = " "
                } else {
                        newChr = Character(UnicodeScalar(ascii + 97)!)
                }
                
                encrypted += String(newChr)
            }
        }
        
        //Show the result
        cypherTextField.text = encrypted.uppercased()
    }
    
    @IBAction func decryptTouchDown(_ sender: Any) {
        let txt = cypherTextField.text!
        var decrypted: String = ""
        
        // Do the encryption
        let plainInt = (Int(keyTextField.text!))
        if let goodInt = plainInt as? Int {
            print("intrat")
            print(txt)
            for chr in txt {
                var newChr: Character
                
                var ascii = Int(UnicodeScalar(String(chr))!.value)
                if ascii == 32 {
                    ascii = 26
                } else {
                    ascii -= 65;
                }
                    
                ascii = (ascii + goodInt) % 27
                if(ascii < 0) {
                    ascii = 27 + ascii;
                }
                if(ascii == 26) {
                    newChr = " "
                } else {
                    newChr = Character(UnicodeScalar(ascii + 65)!)
                }
                
                decrypted += String(newChr)
            }
            
        }
        
        //Show the result
        plainTextField.text = decrypted.lowercased()
        fieldTextChanged(plainTextField)
        fieldTextChanged(keyTextField)
        fieldTextChanged(cypherTextField)
    }
    
}

